astro theme - growth with starter template, CSS-tailwind. color theme examples: cal.com (background light gray with
white high-contrast content boxes), relevanceai.com (long page layout, sticky menu, pricing comparison of 4 items,
affiliate program page, become a partner page styles, socrative.com - clean layouts, javascript images on assessments, clean 4 verticals pricing comparison, homebuddy ( dropdowns, content, SEO), mailbakery.com/blog (blog view of larger images of topics and a TOC on the side with LSA, contact form, and category boxes), brand colors (for client choices to have full color theme choices (but keep it very limited)), 123rf.com charts and graphics, dribbble.com (charts - (example: https://dribbble.com/shots/605727-Infographic-Agro-Chart-Illustration-data-visualization/attachments/640352?mode=media , dashboards),

---

## Component Architecture (Client Demo System)

### Pricing Tiers
| Plan | Price | Pages |
|------|-------|-------|
| Basic | $396 | 6 (Home, About, Services, Contact, Gallery, Team) |
| Add-on | +$69 | +1 page |

### Component Structure
```
/components/
├── core/        (all plans: Nav, Footer, Hero, ContactForm)
├── basic/       ($396: Gallery, TeamGrid, ServiceCards)
├── premium/     (upgrade: PricingTable, BlogLayout, Testimonials, FAQ)
```

### Demo Flow
1. Client picks trade type
2. Brand colors auto-apply
3. Toggle components by plan tier
4. Deploy via Coolify
### Typography
| Type | Options |
|------|---------|
| Headers | Titan One, Arial Black, Google Sans |
| Body | Trebuchet, Montserrat, Arial |
### Build Tools (Priority)
| Tool | Use |
|------|-----|
| GitHub | Template storage |
| Coolify | Deploy |
| Unsplash | Demo images |
| Docuseal | Contracts + JSON automation + signing (backup: Docusign, OneSign) |
| Cal.com | Booking embed |
| Tally.so | Forms → n8n |
| NocoDB | Client CRM |

