# n8n Workflow Automation - API & Reference Documentation

> Fetched via Context7 MCP - 2026-02-02

---

## Table of Contents
1. [Workflows API](#workflows-api)
2. [Credentials API](#credentials-api)
3. [Webhook Triggers](#webhook-triggers)
4. [Code Node & JavaScript](#code-node--javascript)
5. [Expressions Syntax](#expressions-syntax)
6. [Built-in Variables & Methods](#built-in-variables--methods)
7. [Schedule Trigger & Cron](#schedule-trigger--cron)

---

## Workflows API

Base URL: `https://<n8n-domain>/api/v1`

Authentication: `X-N8N-API-KEY: your-api-key`

### Create Workflow
```http
POST /api/v1/workflows
```

**Request Body:**
```json
{
    "name": "My API Workflow",
    "nodes": [
      {
        "parameters": {},
        "name": "Start",
        "type": "n8n-nodes-base.start",
        "typeVersion": 1,
        "position": [250, 300]
      }
    ],
    "connections": {},
    "settings": {}
}
```

**Response (201):**
```json
{
  "id": "1234",
  "name": "My API Workflow",
  "active": false,
  "createdAt": "2023-01-01T12:00:00Z"
}
```

### Get Workflow
```http
GET /api/v1/workflows/{id}
```

### Update Workflow
```http
PUT /api/v1/workflows/{id}
```

**Request Body:**
```json
{
    "name": "Updated Workflow Name",
    "nodes": [
      {
        "parameters": {},
        "name": "Start",
        "type": "n8n-nodes-base.start",
        "typeVersion": 1,
        "position": [250, 300]
      },
      {
        "parameters": {},
        "name": "NewNode",
        "type": "n8n-nodes-base.noOp",
        "typeVersion": 1,
        "position": [450, 300]
      }
    ],
    "connections": {
      "Start": [
        {
          "node": "NewNode",
          "type": "main",
          "index": 0
        }
      ]
    }
}
```

### Activate Workflow
```http
POST /api/v1/workflows/{id}/activate
```

### Deactivate Workflow
```http
POST /api/v1/workflows/{id}/deactivate
```

### Delete Workflow
```http
DELETE /api/v1/workflows/{id}
```

### List Workflows
```http
GET /api/v1/workflows?active=true&tags=production&limit=50
```

**Query Parameters:**
- `active` (boolean) - Filter by active status
- `tags` (string) - Comma-separated list of tags
- `limit` (integer) - Limit results

---

## Credentials API

### Create Credentials
```http
POST /rest/credentials
```

**Request Body:**
```json
{
   "name": "MyAirtable",
   "type": "airtableApi",
   "nodesAccess": [
      {
         "nodeType": "n8n-nodes-base.airtable"
      }
   ],
   "data": {
      "apiKey": "q12we34r5t67yu"
   }
}
```

**Response:**
```json
{
   "data": {
      "name": "MyAirtable",
      "type": "airtableApi",
      "id": "29",
      "createdAt": "2021-09-10T07:41:27.777Z",
      "updatedAt": "2021-09-10T07:41:27.777Z"
   }
}
```

---

## Webhook Triggers

### Execute Workflow via Webhook
```http
POST /webhook/{webhook-path}
```

**Request Body:**
```json
{
  "credentials": {
    "username": "user@example.com",
    "apiKey": "user_api_key"
  },
  "parameters": {
    "param1": "value1",
    "param2": "value2"
  }
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "result": "Workflow executed successfully"
  },
  "executionId": "exec_12345"
}
```

---

## Code Node & JavaScript

### Run Once for All Items
```javascript
const items = $input.all();

const results = items.map(item => {
  return {
    json: {
      originalName: item.json.name,
      processedName: item.json.name.toUpperCase(),
      timestamp: new Date().toISOString(),
      itemCount: items.length
    }
  };
});

return results;
```

### Run Once for Each Item
```javascript
const currentItem = $input.item;
const data = $json;

return {
  json: {
    ...data,
    processed: true,
    calculatedValue: data.price * data.quantity
  }
};
```

### Access Data from Other Nodes
```javascript
const webhookData = $('Webhook').first().json;
const allHttpItems = $('HTTP Request').all();
const lastItem = $('Previous Node').last();
```

### Environment & Workflow Variables
```javascript
const apiUrl = $vars.API_BASE_URL;
const secret = $env.MY_SECRET;  // self-hosted only
```

### Execution Context
```javascript
const executionId = $execution.id;
const isManualRun = $execution.mode === 'manual';
const workflowName = $workflow.name;
```

### Date Operations with Luxon
```javascript
const now = DateTime.now();
const futureDate = now.plus({ days: 30 });
const formatted = futureDate.toFormat('yyyy-MM-dd');
```

### Error Handling
```javascript
try {
  const result = riskyOperation();
  return [{ json: { success: true, data: result } }];
} catch (error) {
  return [{ json: { success: false, error: error.message } }];
}
```

### Async Operations
```javascript
const response = await fetch('https://api.example.com/data');
const data = await response.json();
return [{ json: data }];
```

---

## Expressions Syntax

Use `{{ }}` notation for dynamic parameter values.

### Basic Access
```javascript
{{ $json.body.city }}
{{ $json['user']['profile']['email'] }}
{{ $json.price * 1.1 }}
{{ $json.name.toUpperCase() }}
```

### Conditional
```javascript
{{ $json.status === 'active' ? 'Enabled' : 'Disabled' }}
```

### Access Specific Nodes
```javascript
{{ $('HTTP Request').item.json.response }}
{{ $('Webhook').all() }}
```

### Metadata
```javascript
{{ $workflow.name }}
{{ $workflow.id }}
{{ $execution.id }}
{{ $execution.mode }}
```

### Date/Time
```javascript
{{ DateTime.now().toISO() }}
{{ DateTime.fromISO($json.date).plus({ days: 7 }).toFormat('yyyy-MM-dd') }}
```

### Complex Logic (IIFE)
```javascript
{{(()=>{
  let end = DateTime.fromISO('2024-03-13');
  let start = DateTime.fromISO('2024-02-13');
  let diffInMonths = end.diff(start, 'months');
  return diffInMonths.toObject();
})()}}
```

### JMESPath Queries
```javascript
{{ $jmespath($json.users, "[?age > `30`].name") }}
```

---

## Built-in Variables & Methods

### Current Node Input
| Method | Description |
|--------|-------------|
| `$input.item` | Current item being processed |
| `$input.all()` | All input items |
| `$input.first()` | First input item |
| `$input.last()` | Last input item |
| `$json` | Shorthand for `$input.item.json` |
| `$binary` | Shorthand for `$input.item.binary` |

### Access Other Nodes
| Method | Description |
|--------|-------------|
| `$('Node Name').item` | Paired item from named node |
| `$('Node Name').first()` | First item from named node |
| `$('Node Name').last()` | Last item from named node |
| `$('Node Name').all()` | All items from named node |
| `$('Node Name').itemMatching(0)` | Item at specific index |

### Workflow & Execution
| Variable | Description |
|----------|-------------|
| `$workflow.id` | Workflow ID |
| `$workflow.name` | Workflow name |
| `$workflow.active` | Whether workflow is active |
| `$execution.id` | Current execution ID |
| `$execution.mode` | 'manual', 'trigger', or 'webhook' |
| `$execution.resumeUrl` | URL to resume waiting execution |

### Environment & Variables
| Variable | Description |
|----------|-------------|
| `$env.VARIABLE_NAME` | Environment variable (self-hosted) |
| `$vars.variableName` | Workflow variable |

### Date & Time (Luxon)
| Variable | Description |
|----------|-------------|
| `$now` | Current DateTime |
| `$today` | Start of today |
| `DateTime.now()` | Current DateTime |
| `DateTime.fromISO('2024-01-15')` | Parse ISO date |
| `DateTime.fromFormat('15/01/2024', 'dd/MM/yyyy')` | Parse custom format |

### Utility
| Variable | Description |
|----------|-------------|
| `$runIndex` | Current run index in loop |
| `$itemIndex` | Current item index |
| `$nodeVersion` | Version of current node |
| `$position` | Position in workflow |

---

## Schedule Trigger & Cron

### Custom Cron Expression
Set **Trigger Interval** to **Custom (Cron)** and enter a cron expression.

Generate expressions at: https://crontab.guru

**Common Cron Patterns:**
| Expression | Schedule |
|------------|----------|
| `0 9 * * *` | Daily at 9:00 AM |
| `0 0 * * 0` | Weekly on Sunday midnight |
| `0 0 1 * *` | Monthly on the 1st |
| `*/15 * * * *` | Every 15 minutes |
| `0 9-17 * * 1-5` | Hourly 9AM-5PM weekdays |

**Troubleshooting:** If you get "Invalid cron expression", verify syntax and test on crontab.guru (remove seconds column if present).

---

## Example: Complete Workflow JSON

```json
{
  "meta": {
    "templateCredsSetupCompleted": true
  },
  "nodes": [
    {
      "parameters": {},
      "name": "When clicking \"Execute workflow\"",
      "type": "n8n-nodes-base.manualTrigger",
      "typeVersion": 1,
      "position": [780, 600]
    },
    {
      "parameters": {
        "url": "https://api.example.com/data",
        "authentication": "genericCredentialType",
        "genericAuthType": "httpHeaderAuth",
        "options": {}
      },
      "name": "HTTP Request",
      "type": "n8n-nodes-base.httpRequest",
      "typeVersion": 4.1,
      "position": [1000, 500],
      "credentials": {
        "httpHeaderAuth": {
          "id": "credential-id",
          "name": "My API Credentials"
        }
      }
    },
    {
      "parameters": {
        "sendTo": "email@example.com",
        "subject": "Report Ready",
        "emailType": "text",
        "message": "Your report is attached.",
        "options": {
          "attachmentsUi": {
            "attachmentsBinary": [{}]
          }
        }
      },
      "name": "Gmail",
      "type": "n8n-nodes-base.gmail",
      "typeVersion": 2.1,
      "position": [1200, 500],
      "credentials": {
        "gmailOAuth2": {
          "id": "gmail-cred-id",
          "name": "Gmail Account"
        }
      }
    }
  ],
  "connections": {
    "When clicking \"Execute workflow\"": {
      "main": [[{"node": "HTTP Request", "type": "main", "index": 0}]]
    },
    "HTTP Request": {
      "main": [[{"node": "Gmail", "type": "main", "index": 0}]]
    }
  }
}
```

---

## cURL Examples

```bash
# Create a new workflow
curl -X 'POST' \
  'https://your-n8n.com/api/v1/workflows' \
  -H 'X-N8N-API-KEY: your-api-key' \
  -H 'Content-Type: application/json' \
  -d '{"name": "My Workflow", "nodes": [...], "connections": {}}'

# Activate a workflow
curl -X 'POST' \
  'https://your-n8n.com/api/v1/workflows/1000/activate' \
  -H 'X-N8N-API-KEY: your-api-key'

# List active workflows
curl -X 'GET' \
  'https://your-n8n.com/api/v1/workflows?active=true' \
  -H 'X-N8N-API-KEY: your-api-key'
```

---

*Source: n8n-io/n8n-docs via Context7*
# n8n API Reference (Context7 - 2026-02-02)

## Workflows API
Base: `https://<domain>/api/v1` | Auth: `X-N8N-API-KEY: <key>`

| Method | Endpoint | Purpose |
|--------|----------|---------|
| POST | /workflows | Create workflow |
| GET | /workflows/{id} | Get workflow |
| PUT | /workflows/{id} | Update workflow |
| POST | /workflows/{id}/activate | Activate |
| POST | /workflows/{id}/deactivate | Deactivate |
| DELETE | /workflows/{id} | Delete |
| GET | /workflows?active=true&limit=50 | List |

## Credentials: `POST /rest/credentials`
```json
{"name":"MyAPI","type":"airtableApi","nodesAccess":[{"nodeType":"n8n-nodes-base.airtable"}],"data":{"apiKey":"xxx"}}
```

## Webhook: `POST /webhook/{path}`
```json
{"credentials":{"apiKey":"xxx"},"parameters":{"param1":"value1"}}
```

## Code Node JavaScript
```javascript
// All items
const items = $input.all();
return items.map(i => ({json:{...i.json,processed:true}}));

// Each item
return {json:{...$json,calc:$json.price*$json.qty}};

// Other nodes
$('Webhook').first().json; $('HTTP Request').all();

// Vars & env
$vars.API_URL; $env.SECRET; $execution.id; $workflow.name;

// Dates (Luxon)
DateTime.now().plus({days:30}).toFormat('yyyy-MM-dd');
```

## Expressions `{{ }}`
```
{{$json.field}} {{$json.price*1.1}} {{$json.status==='active'?'Yes':'No'}}
{{$('Node').item.json.data}} {{DateTime.now().toISO()}}
{{$jmespath($json.users,"[?age>`30`].name")}}
```

## Built-in Variables
| Var | Use |
|-----|-----|
| $input.item/.all()/.first()/.last() | Current node data |
| $json, $binary | Shorthand input |
| $('Node').item/.all()/.first() | Other node data |
| $workflow.id/.name/.active | Workflow meta |
| $execution.id/.mode | Execution meta |
| $env.VAR, $vars.name | Environment/workflow vars |
| $now, $today, DateTime | Date/time |
| $runIndex, $itemIndex | Loop position |

## Cron (Schedule Trigger)
`0 9 * * *` daily 9am | `*/15 * * * *` every 15min | `0 0 * * 0` weekly Sun
Test: crontab.guru

*Source: n8n-io/n8n-docs*
