# Claude Code Workflows & Automation Resources

> Curated reference library for building production-grade automation sequences.
> Last updated: 2026-01-31

---

## Quick Links

| Resource | URL | Purpose |
|----------|-----|---------|
| Anthropic Academy | https://anthropic.skilljar.com/ | Official courses |
| Claude Code in Action | https://anthropic.skilljar.com/claude-code-in-action | Hands-on course |
| 100+ Subagents Collection | https://github.com/kelvincushman/claudecode-agents-skills | Production agents |
| Official Skills Repo | https://github.com/anthropics/skills | Skill templates |
| Hooks Guide | https://code.claude.com/docs/en/hooks-guide | Automation triggers |

---

## Learning Resources

### Anthropic Academy Courses
- **Claude Code in Action**: https://anthropic.skilljar.com/claude-code-in-action
- **Claude 101**: https://anthropic.skilljar.com/claude-101
- **Build with Claude**: https://www.anthropic.com/learn/build-with-claude
- **Claude for Work**: https://www.anthropic.com/learn/claude-for-work

### Documentation
- **Hooks Reference**: https://code.claude.com/docs/en/hooks
- **Skills Guide**: https://code.claude.com/docs/en/skills
- **Subagents Guide**: https://code.claude.com/docs/en/sub-agents
- **Plugins Guide**: https://code.claude.com/docs/en/plugins
- **Full Docs Index**: https://code.claude.com/docs/llms.txt

### Community Resources
- **Starter Template Guide**: https://aimaker.substack.com/p/claude-code-guide-starter-template
- **100+ Subagent Collection**: https://dev.to/voltagent/100-claude-code-subagent-collection-1eb0

---

## Subagent Categories (110+ Available)

### 1. Core Development (9 agents)
- `api-designer` - REST/GraphQL API architecture
- `frontend-developer` - UI/UX implementation
- `backend-developer` - Server-side logic
- `fullstack-developer` - End-to-end development
- `mobile-developer` - iOS/Android apps
- `graphql-architect` - GraphQL schema design

### 2. Language Specialists (22 agents)
TypeScript, Python, JavaScript, Rust, Java, Go, .NET, PHP, React, Vue, Angular, and 15+ more framework-specific experts.

### 3. Infrastructure (12 agents)
- `devops-engineer` - CI/CD, deployment
- `cloud-architect` - AWS/GCP/Azure
- `kubernetes-specialist` - Container orchestration
- `terraform-engineer` - Infrastructure as code
- `database-admin` - DB optimization
- `incident-responder` - Production issues

### 4. Quality & Security (12 agents)
- `code-reviewer` - Code quality
- `test-engineer` - Testing strategies
- `security-auditor` - Vulnerability assessment
- `penetration-tester` - Security testing
- `performance-engineer` - Optimization
- `accessibility-specialist` - A11y compliance

### 5. Data & AI (12 agents)
- `data-engineer` - Data pipelines
- `ml-engineer` - Machine learning
- `llm-architect` - LLM integration
- `prompt-engineer` - Prompt optimization
- `data-analyst` - Analytics

### 6. Business & Product (10 agents)
- `project-manager` - Task coordination
- `product-manager` - Feature planning
- `technical-writer` - Documentation
- `ux-researcher` - User research

### 7. Meta & Orchestration (8 agents)
- Multi-agent coordination
- Workflow automation
- Error handling
- Task distribution

---

## Hooks Reference

### Event Types
| Event | When It Fires | Use Case |
|-------|---------------|----------|
| `SessionStart` | Session begins/resumes | Inject context |
| `UserPromptSubmit` | Before processing prompt | Validate input |
| `PreToolUse` | Before tool executes | Block actions |
| `PostToolUse` | After tool succeeds | Auto-format |
| `PostToolUseFailure` | After tool fails | Error handling |
| `Notification` | Claude needs attention | Desktop alerts |
| `SubagentStart` | Subagent spawned | Logging |
| `SubagentStop` | Subagent finished | Cleanup |
| `Stop` | Claude finishes responding | Verification |
| `PreCompact` | Before context compaction | Save state |
| `SessionEnd` | Session terminates | Cleanup |

### Hook Types
- `command` - Run shell scripts
- `prompt` - Single-turn LLM evaluation
- `agent` - Multi-turn verification with tools

### Example: Auto-Format After Edits
```json
{
  "hooks": {
    "PostToolUse": [
      {
        "matcher": "Edit|Write",
        "hooks": [
          {
            "type": "command",
            "command": "jq -r '.tool_input.file_path' | xargs npx prettier --write"
          }
        ]
      }
    ]
  }
}
```

### Example: Desktop Notifications (Linux)
```json
{
  "hooks": {
    "Notification": [
      {
        "matcher": "",
        "hooks": [
          {
            "type": "command",
            "command": "notify-send 'Claude Code' 'Claude Code needs your attention'"
          }
        ]
      }
    ]
  }
}
```

### Example: Block Protected Files
```json
{
  "hooks": {
    "PreToolUse": [
      {
        "matcher": "Edit|Write",
        "hooks": [
          {
            "type": "command",
            "command": "\"$CLAUDE_PROJECT_DIR\"/.claude/hooks/protect-files.sh"
          }
        ]
      }
    ]
  }
}
```

---

## Skills Structure

### Basic Skill Template
```
my-skill/
├── SKILL.md          # Required: instructions + metadata
├── scripts/          # Optional: supporting files
└── resources/        # Optional: additional assets
```

### SKILL.md Format
```yaml
---
name: my-skill-name
description: What this skill does and when to use it
---

# My Skill Name

## Purpose
[What the skill accomplishes]

## Instructions
[Step-by-step guidance]

## Examples
- [Usage scenario 1]
- [Usage scenario 2]

## Guidelines
- [Behavior rule 1]
- [Behavior rule 2]

## Output Format
[Expected format specification]
```

### Official Skills Categories
- **DOCX** - Word document manipulation
- **PDF** - PDF forms and extraction
- **PPTX** - PowerPoint creation
- **XLSX** - Excel analysis

### Installing Skills
```bash
# Register marketplace
/plugin marketplace add anthropics/skills

# Install specific skill
/plugin install document-skills@anthropic-agent-skills
```

---

## Subagent Configuration

### Storage Locations
- **Project-level**: `.claude/agents/` (current project only)
- **Global-level**: `~/.claude/agents/` (all projects)

### Agent YAML Format
```yaml
---
name: subagent-name
description: Brief description of capabilities
tools: List of MCP tools used
---
[Role definition and expertise content]
```

### Usage Commands
```bash
# Open agent manager
/agents

# Invoke specific agent
> Have the [agent-name] subagent [perform task]
```

---

## Best Practices (Veteran IT/Marketing Standards)

### Workflow Design
1. **Clear, measurable goals** for each automation step
2. **A/B testing** for message variations
3. **Personalization at scale** using dynamic data
4. **Optimal timing** based on data analysis
5. **Graceful error handling** with fallbacks
6. **Human escalation paths** for edge cases
7. **Continuous feedback loops** for improvement

### Target: 98% Success Rate
- Weekly review cycles
- Iteration logging
- Metric tracking
- Rollback plans

### Core Components
1. **CLAUDE.md** - Persistent instructions and preferences
2. **Commands** (`.claude/commands/`) - On-demand workflows
3. **Agents** (`.claude/agents/`) - Autonomous processes
4. **Hooks** - Lifecycle automation triggers
5. **Skills** - Specialized task instructions

---

## Integration Stack Reference

### Voice/SMS Outreach
| Tool | Purpose | Docs |
|------|---------|------|
| Retell AI | Voice agents | https://retell.ai/docs |
| Bland AI | Conversational calls | https://bland.ai/docs |
| Vapi | Voice API platform | https://vapi.ai/docs |
| Twilio | SMS/Voice | https://twilio.com/docs |

### Data & CRM
| Tool | Purpose | Local URL |
|------|---------|-----------|
| NocoDB | Visual DB/Kanban | http://localhost:8080 |
| PocketBase | Real-time backend | http://localhost:8090 |
| Supabase | Cloud database | Cloud hosted |

### Automation
| Tool | Purpose | Local URL |
|------|---------|-----------|
| n8n | Workflow automation | http://localhost:5678 |
| Cal.com | Scheduling | API integrated |
| Apify | Web scraping | API integrated |

---

## File Locations

```
~/.claude/
├── settings.json           # Global settings + hooks
├── agents/                 # Global subagents
└── keybindings.json        # Custom shortcuts

.claude/
├── settings.json           # Project settings + hooks
├── settings.local.json     # Local overrides (gitignored)
├── agents/                 # Project subagents
├── commands/               # Custom commands
└── hooks/                  # Hook scripts

/mnt/c/Users/password/Documents/.claude/
├── templates/              # Prompt templates
├── prompts/                # Saved prompts
├── workflows/              # This documentation
├── agents/                 # Agent registry
└── docker/                 # Container configs
```

---

## Changelog

| Date | Change |
|------|--------|
| 2026-01-31 | Initial resource compilation |
