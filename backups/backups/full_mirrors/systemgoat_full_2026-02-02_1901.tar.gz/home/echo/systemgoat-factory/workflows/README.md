# Workflows & Automation Reference

> Central hub for all outreach sequences, automation workflows, and business processes.

## Directory Structure

```
workflows/
├── README.md                    # This file
├── outreach/                    # Customer finding & outreach sequences
│   ├── customer-discovery.md
│   ├── call-text-sequences.md
│   └── follow-up-automation.md
├── integrations/                # Tool-specific configurations
│   ├── retell-config.md
│   ├── bland-config.md
│   ├── vapi-config.md
│   ├── twilio-config.md
│   └── n8n-workflows.md
├── data-flows/                  # Data pipeline documentation
│   ├── nocodb-schemas.md
│   ├── pocketbase-collections.md
│   └── sync-strategies.md
└── reviews/                     # Weekly improvement logs
    └── YYYY-WW-review.md
```

## Active Workflows

| Workflow | Status | Success Rate | Last Review | Next Review |
|----------|--------|--------------|-------------|-------------|
| Customer Discovery | Draft | -- | -- | -- |
| Outreach Sequence | Draft | -- | -- | -- |
| Follow-up Automation | Draft | -- | -- | -- |

## Integration Stack

### Voice/SMS Outreach
- **Retell AI**: Voice agents for inbound/outbound calls
- **Bland AI**: Conversational AI phone calls
- **Vapi**: Voice API platform
- **Twilio**: SMS/Voice programmable communications

### Data & CRM
- **NocoDB**: Visual database, kanban boards, CRM views
- **PocketBase**: Real-time backend, auth, file storage
- **Supabase**: Cloud database, real-time subscriptions
- **GitHub**: Version control, workflow storage

### Automation
- **n8n**: Workflow automation (localhost:5678)
- **Cal.com**: Scheduling automation
- **Apify**: Web scraping and data extraction

## Weekly Review Process

**Schedule**: Every [DAY] via Cal.com reminder

### Review Checklist
1. [ ] Pull latest metrics from NocoDB
2. [ ] Analyze success/failure rates
3. [ ] Identify bottlenecks in sequences
4. [ ] Update prompts based on outcomes
5. [ ] Test changes in staging
6. [ ] Document improvements in iteration log
7. [ ] Commit changes to GitHub

### Target: 98% Success Rate

Based on best practices from veteran IT/marketing professionals:
- Clear, measurable goals for each step
- A/B testing for message variations
- Personalization at scale
- Optimal timing based on data
- Graceful error handling
- Human escalation paths
- Continuous feedback loops

## Quick Links

- [Prompt Template](../templates/prompt-template.md)
- [Agent Registry](../agents/agent-registry.md)
- [n8n Dashboard](http://localhost:5678)
- [NocoDB](http://localhost:8080)
- [PocketBase](http://localhost:8090)

## Changelog

| Date | Change | Author |
|------|--------|--------|
| 2026-01-31 | Initial structure created | Claude |
