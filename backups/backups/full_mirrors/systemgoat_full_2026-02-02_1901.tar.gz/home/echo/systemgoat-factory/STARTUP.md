# CLAUDE SESSION STARTUP

**User: Paste this command at the start of EVERY session:**
```
Read /mnt/c/Users/password/Documents/.claude/STARTUP.md
```

---

## CLAUDE: Execute these steps automatically (no user prompting):

### STEP 1: Read Rules
```
Read /mnt/c/Users/password/Documents/.claude/RULES.md
```

### STEP 2: Read NocoDB Tasks (95 tasks - source of truth)
```bash
curl -s -H "xc-token: QEkBy3A48Fzn6CW4FCaQHfVGICmC4_kaYEPtMR7k" "http://localhost:8080/api/v2/tables/micl8z8rf5h7cpm/records?limit=100"
```

### STEP 3: Read Memory
```
mcp__memory__read_graph
```

### STEP 4: Check Docker
```bash
docker ps --format "table {{.Names}}\t{{.Status}}"
```

### STEP 5: Report to User
Provide summary:
- Tasks completed
- Tasks in progress (with %)
- Top 5 priority tasks (with Delegate scores)
- Docker status
- Any blockers

---

## CRITICAL RULE: TOKEN ESTIMATION

**BEFORE any search or task, Claude MUST:**
```
Est. tokens: [number] | Task: [description] | Proceed? (Y/N)
```
Wait for user approval on high-token tasks (>500).

---

## DELEGATION RULE (Apply to EVERY task)

**Calculate before starting ANY work:**
```
DELEGATE_SCORE = (Type × 0.25) + (Context_Risk × 0.20) + (Token_Savings × 0.20) + (Complexity × 0.20) + (Time × 0.15)
```

| Score | Action |
|-------|--------|
| 7-10 | MUST delegate to subagent |
| 4-6 | Consider delegating |
| 1-3 | Do directly |

---

## NocoDB API

| Setting | Value |
|---------|-------|
| URL | http://localhost:8080 |
| Base | popj9o25eiv8w3p |
| Table | micl8z8rf5h7cpm |
| Token | QEkBy3A48Fzn6CW4FCaQHfVGICmC4_kaYEPtMR7k |

---

## CURRENT STATUS (Claude updates at session end)

**Last Updated:** 2026-02-01 14:30 PST

**Google Workspace Email:** admin@buildrightpros.com
**Domain:** buildrightpros.com

**Completed:** #3 Contact form, #10 PocketBase, #38 Planka
**In Progress:** #2 (95%), #11 (25%), #24 (5%), #59 (10%), #76 (15%)

**Hetzner/Coolify (5.75.146.160):**
- Coolify: ✅ (coolify, proxy, db, redis, realtime, sentinel)
- n8n (production): ✅ via Coolify

**Docker Local (WSL):**
- NocoDB: 8080 ✅
- PocketBase: 8090 ✅
- n8n (dev): 5678 ✅
- Ntfy: 8095 ✅
- Planka: 3000 ✅
- Metabase: 3001 ✅
- DocuSeal: 3002 ❌ (DATABASE_URL error)

**Cloud Backups:**
- GitHub: ❌ needs `gh auth login`
- NocoDB: ✅ 95 tasks online
- OneDrive: ✅ manual backup

---

## SESSION END CHECKLIST

Before user signs off, Claude MUST:
1. Update NocoDB with task progress
2. Update MCP memory with new facts
3. Update this CURRENT STATUS section
4. Tell user: "Next session: `Read /mnt/c/Users/password/Documents/.claude/STARTUP.md`"
