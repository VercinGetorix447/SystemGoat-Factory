# Agent Registry
> Save this file - it lists all configured subagents

## Location
All agents stored in: `~/.claude/agents/`

---

## Development Agents

| Agent | Model | Purpose |
|-------|-------|---------|
| architect | opus | System design, patterns, structural decisions |
| code-reviewer | sonnet | Code quality, security review after changes |
| debugger | sonnet | Error diagnosis, root cause analysis, fixes |
| refactorer | sonnet | Code structure improvements without behavior change |
| test-runner | haiku | Execute tests, analyze failures |
| performance-optimizer | sonnet | Bottleneck identification and optimization |
| security-auditor | sonnet | Vulnerability scanning, OWASP checks |

## Research & Documentation

| Agent | Model | Purpose |
|-------|-------|---------|
| researcher | sonnet | Codebase exploration, documentation research |
| doc-writer | sonnet | README, API docs, technical writing |
| api-designer | sonnet | REST/GraphQL endpoint design |

## Operations

| Agent | Model | Purpose |
|-------|-------|---------|
| devops-engineer | sonnet | CI/CD, Docker, cloud infrastructure |
| git-specialist | haiku | Version control, branching, history |
| data-analyst | sonnet | SQL queries, data exploration |

## Project Management

| Agent | Model | Purpose |
|-------|-------|---------|
| project-manager | sonnet | Progress tracking, daily reports |
| task-tracker | haiku | Task completion verification |
| context-keeper | sonnet | Session state, context maintenance |
| agent-router | haiku | Routes tasks to appropriate agents |

## Content & Automation (n8n)

| Agent | Model | Purpose |
|-------|-------|---------|
| content-generator | sonnet | Blog posts, articles, marketing copy |
| social-media | haiku | Platform-specific social content |
| content-repurposer | sonnet | Transform content across formats |
| n8n-workflow | sonnet | n8n automation workflow design |

## Business Automation (NEW 2026-01-31)

| Agent | Model | Purpose |
|-------|-------|---------|
| session-backup-agent | sonnet | 10-min activity monitoring, daily logs, multi-destination backup |
| research-coordinator-agent | sonnet | Best practice research, tool updates, agent performance evaluation |
| business-orchestrator-agent | opus | Master coordinator for outreach, operations, analytics domains |

### Session Backup Agent
- **Triggers**: Every 10 minutes, SessionEnd, `/backup`
- **Outputs**: Daily reports, GitHub commits, PocketBase records
- **Features**: Missing field alerts, EOD summaries, next-day to-do generation

### Research Coordinator Agent
- **Triggers**: Daily, on task blocked, `/research`
- **Outputs**: Research reports, tool update notices, improvement recommendations
- **Features**: Web search, documentation lookup, performance scoring

### Business Orchestrator Agent
- **Triggers**: On demand, workflow routing
- **Domains**: Outreach (lead gen, voice AI, content), Operations (hiring, contracts, invoicing), Analytics (KPIs, reporting)
- **Features**: Cost-optimized tool selection (Retell/Bland/Vapi), funnel stage routing, 98% success target

---

## Quick Reference

**Total Agents:** 24

**By Model:**
- opus: 1 (architect)
- sonnet: 16
- haiku: 4 (test-runner, task-tracker, git-specialist, agent-router, social-media)

**Proactive Agents** (auto-invoke):
- code-reviewer - after code changes
- debugger - when errors occur
- security-auditor - with auth/input handling
- project-manager - session start/end
- context-keeper - every 15-20 interactions

---

## Restore Command
If agents are lost, restore from file-history:
```bash
for f in ~/.claude/file-history/293ec0b9-949f-4ff1-8149-d0a274e59faf/*@v2; do
  name=$(head -2 "$f" | grep "^name:" | cut -d: -f2 | tr -d ' ')
  [ -n "$name" ] && cp "$f" ~/.claude/agents/"$name".md
done
```
