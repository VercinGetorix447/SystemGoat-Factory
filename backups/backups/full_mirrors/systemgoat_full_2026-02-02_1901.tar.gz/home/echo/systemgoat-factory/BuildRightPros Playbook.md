# OPERATIONS

# OPERATIONS

Files to assist in persistent memory for agents listed in the knowledge\_base and saved in stored folders in System Goat Factory repository files.

## **REPOSITORY FILES**

* [index.md](http://index.md) \- folder trees and overviews of the project and where information is stored, list   
* style\_guide.md \- the coding voice, css overviews and examples of current assets found online or during feedback to give a visual interpretation of what we like  
* [strategy.md](http://strategy.md) \- goals of project and the high level output expected from each task, the long term memory that will never be overlooked when context windows expire  
* [assets.md](http://assets.md) \- the applications, hardware and systems accessed, tools available, when they are used and the how to use them a list of agent functions and how they are called upon for delegation of work  
* working\_agreement.md \- a master file of expectations of interactions, formatting and constraints within the interactions, basically the prompt language theme overview; teaching your personality type and interaction expectations; the degree of pushback desired; decision making temperature with level of hallucination detailed based on type and degree of importance; the details of what happens and when it happens for recurrent tasks (such as start and eod expectations)  
* [testing.md](http://testing.md) \- tdd style and how we do test first development with red-green refactoring style.  
* Domain\_language.md \- terminology used, vocabulary and language used, tables for calculating algorithms for decision making with headings for each higher level output  
* Tasks.md \- task lists with dependencies and priority lists for constant updates and changes during day to day work.   
* [Sessions.md](http://Sessions.md) \- set /compact to give fresh summary of previous sessions without losing context window but cleans up context window, set /clear compact to clear context of previous chats to focus on new or different project

[MCP tools]() to be used by the system are described in the tools tab.

# TOOLS AND USAGE

# REPOSITORY

## **Index** 

overview of the other repositories, their functions and how they are to be called upon.

## **Strategy of repository**

- Prioritize iteration and modularization over code duplication  
- Proactively suggest performance improvements  
- Identify potential side effects such as security issues, vulnerabilities to project, and solutions to proactively avoid any unacceptable risks (those over 15%),   
- Include comments to clarify technical concepts, functions and expected changes  
- Favor functional and declarative patterns over class-based approaches  
- Use subagents based on ROI (34% time savings, 33% token savings, 33%complexity)

## **Assets** \- Tools being used

# MCP LISTS AND LINKS

| MCP Server | Primary Purpose |  ROI Score | Ease Use | Why it's a "Top Choice" |
| :---- | :---- | ----- | ----- | :---- |
| [GitHub (Official)](https://github.com/VercinGetorix447/SystemGoat-Factory/blob/main/agents/business-orchestrator-agent.md) | Workflow Sync | 10 | 8 | The backbone of your setup. Manages code and app versions without manual uploads. |
| [NocoDB](http://localhost:8080/dashboard/#/nc/popj9o25eiv8w3p?page=collaborator) | Business Database | 10 | 9 | Essential for B2C leads. It turns complex data into an "Airtable-like" grid your team can use. |
| [Playwright](https://playwright.dev/) | Web Automation | 9 | 7 | Visual Designer if you use screenshots; Automates B2C lead scraping and site updates. Superior to Ref.tools for business scaling. |
| Semgrep | Security Brain | 9 | 10 | KEEP. It silently blocks vulnerabilities in the background so your team doesn't have to debug. |
| System Monitor | PC Health (CPU/RAM) | 8 | 10 | NEW. Specifically monitors Ubuntu resources to ensure background apps don't lag your PC. |
| Pieces MCP | In app memory | 8 | 7 | Brings desktop memory to projects beyond the prompts used in Claude. Helps with persistent memory flaws |
| Docker | containerizing | 10 | 9 | Sort and containerize for easily calling apps and proper routing  |
| Supabase | database | 9 | 9 | Store apps and data for cloud access; cloud backup |
| pocketbase | database | 10 | 8.5 | Store apps and data, maintain directory tree within applications  |
| jit.si | Meeting software | 9 | 9 | Meeting software to embed in code on page for client interaction and virtual demonstrations |
| contact 7 | Efficient subagent calls | 10 | 8 | References documentation of all API in file tree for subagents to work efficiently |
| coolify | Deployment engine | 10 | 9 | Deploys apps and enables auto-routing through Traefik for auto SSL certificates |
| metabase | Charts and tables | 8 | 8 | Chart, graph and visual dashboards from database integration (nocoDB) |
| tally.so | Basic forms | 8.5 | 9 | Basic form builder for n8n integrations, webhooks, and good UX, can upgrade to custom react or jotform later |
| planka | kanban | 8 | 9 | Assists database in creating easy and transferable kanban boards for client CRM |
| Plausible analytics | Evaluation and monitoring | 8 | 9 | 10x faster than Google Analytics without branding and no limits |
| bland.ai | Voice tts | 10 | 10 | Voice outreach app which can use extremely low  |
| AI Studio Gemini flash 2.5 | Voice app | 10 | 8.5 | Llm to use with TTS and STT for quick latency, good quality and low cost (retell, vapi later) |
| docuseal | Contract generation and dig signature | 10 | 9 | Real time contract creation and digital signatures |
| SQ Lite | memory | 10 | 9 | Memory improvement and linking |
| Exas | App context | 9 | 8 | Relevant context improvement for more polished application development |
| File system | File converter | 10 | 8 | Allows LLM to read file types and write to and from the PC |
| cal.com | Scheduling and booking | 10 | 9 | Booking and scheduling agent with great API for automating bookings and meetings |
| Brave search | Online search | 7.5 | 9 | Allows access to fetch data from web and interact with external apps |
| Google cloud speech | TTS and STT | 10 | 9 | Texting and voice agent support for applications and customer interface |
| serper.ai | scraping | 8 | 8 | Efficiency scraper for n8n workflows |
| apify | scraping | 10 | 9 | Data scraping, easy automation with n8n workflows and customer filtering |
| Gemini CLI | LLM | 10 | 8 | Generates apps from different file types, query and edit large codebases, automation help |
| rork | Website clone | 8.5 | 8 | Reads and integrates code from other applications and creations |
| Upsplash | Image directory | 10 | 9 | Integration for image search and fetch for real time client app buildouts and webdev |
| CDK | Reading & integration | 9 | 8 | Integration testing and reading of offline sources |
| whatsapp | Communication & triggers | 9 | 8 | Communication app for automation tools to trigger and make call to actions and give real-time feedback |
| twilio | Phone and communcation | 10 | 9 | Access to lines for outbound and inbound calling, phone numbers for outreach |
| mixpost | Social post scheduling | 9 | 8 | Schedules social posting and content from video or audio or text, randomizer for SEO |
| retell | voice | 9 | 9 | Voice agent using LLM to speak directly with clients and answer questions, incoming calls |
| excalidraw | whiteboard | 9 | 10 | Uses shared whiteboard for drawing and shared client interaction during meetings  |
| convertAPI | File parser | 8 | 8 | Converts file types for app needs, image viewer and competitive research |

Playwright MCP   
Link:  [Playwright Github](https://github.com/microsoft/playwright-mcp)  
Docs: [Dev Documentation](https://playwright.dev/docs/intro#installing-playwright)  
API Key:   
Purpose: To allow web calls and tests from a “visual” editor standpoint.  

## Style Guide

- Use Tailwind CSS to design projects based on approvals by owner and admin, if no direction given, consider modifications based on your knowledge of project details and strategy and suggest necessary changes with table of options using some of the same header columns consistent throughout project (name, function summary, ROI, cost, time needed to implement, est token usage, expected benefit, % of expected success

## **Working Agreement**  

- Prior to beginning any task with new applications and tools, you will fetch the github directory, white papers, and online documentation for the applications and tools being used.   
- Console monitoring: actively fetch and analyze logs from the console, start a new log record at beginning of each session labeled as “session\_update” : “date” & “\_time”  
- Any conversation with more than 50 words of instructions, remind owner to write prompts in google sheets file to transfer over step by step  
- Package installation: Only install packages when explicitly requested. During research of new packages, list in a table with headers for –name \- summary of use \- ROI \- Est of success \- Integration Benefits–.  (est of success is the estimate of successfully downloading needed files and the ability to integrate with the project successfully.

## **Monitor usage and constraints** \- be aware at all times of context window and one of the main priorities is to keep context clean. Communicate efficiently to avoid problems by:

- Use \`ccusage\`   
- Look at ubuntu usage patterns npx ccusage@latest report daily  
- Always outline the logic first, preventing expensive "wrong turns" that burn tokens  
- Instruct owner during conversations randomly to press **Shift+Tab** before a big task in order to save tokens and avoid large loss of context  
- Clear Context: instruct user to use the `/clear` command when switching from different logic types.   
- Limit token usage per activity. Categorize tasks by token usage: quick \<200, small 201-800, mid 801-2000, large 2001-5000, very large 5000-10000, huge \>10000 tokens  
- Default to best practices for specific use case if not explicitly instructed to deviate. Note best practice proactively if you see potential inefficiencies  
- Delegate whenever possible based on guidance of sugagent usage recommendations algorithm (complexity, time, token usage)

## Tool usage and delegation

- Examine what is being done and compare your list of API / MCP tools to your list of agents  
- Identify the use case for integration goal  
- Identify technical constraints or integration issues and requirements  
- Analyze scope and complexity of implementation needed  
- Always be aware of available agents to match with the project and task needs  
- Choose agent based on best potential outcome from your understanding of project  
- If any questions, always ask.  Once deployed, you can delegate that subagent autonomously within that current project  
- Package manager: do not use yarn  
- Server configuration: server runs on port 3000  
- MCP integrations: utilize available MCP servers at your disposal and prioritize best practices used by known authors before creating new methods

## Testing and development

- App router: utilize the app / directory structure (layout.tsx, page.tsx, loading.tsx, error.tsx)  
- Component locations: Place components in \``/apps/components`\`  github, grouped by use case in subdirectories  
- UI: \`/components/ui\` for all new building components and those being built  
- Feature grouping: organize files by domain (eg: features/auth, features/dashboard, etc)  
- Utilities: Use lib/ for low-level logic, supabase clients, and third-party utilities, always store migration and edge functions in the supbase/ directory  
- Directory naming: use lowercase with dashes (eg: components/auth-wizard)  
- Implement helper functions to avoid code duplication, call sub-agents where applicable to double check code consistently

## Domain Language

- Write code in TypeScript format  
- Prefer interface over types for object shapes  
- Use interfaces for component props and data models  
- Replace enums with plain object maps  
- Enable typescript strict \`mode\`  
- Use descriptive variable names with auxiliary verbs (isLoading, hasError, canSubmit)  
- Maintain consistent naming patterns across the codebase

## Documentation Fetch and Retrieval 

Use contact7 MCP to retrieve most current and comprehensive documentation of use and best practices for apps, APIs and MCPs. Be sure to gather:

- Complete API reference documentation  
- Authentication and authorization guides  
- Code examples and best practices  
- Rate limiting and usage guidelines  
- Relevant SDKs or client libraries  
- Store new documentation in relevant github reference if not found internally


## **Document Review**

- Available endpoints and capabilities  
- Required parameters and data formats  
- Response structures and data types  
- Authentication mechanisms and security considerations  
- Integration patterns and recommended approaches

# **Create Strategic Implementation Plan** \- based on analysis, develop a plan that meets the constraints and goals of the project for:

- best usage of the tools available for optimization of time and other resources  
- Analyzes other implementations needed for proactively avoiding problems  
- Delegates based on strategic implementation  
- Asks relevant questions when appropriate without hallucinating


## **Deliver Results** \- present findings from queries and conversations in best method for clear communication

- Use subagents for technical work and summarize their work for learning better methods as needed  
- Present recommendations in a clear and concise method  
- Prioritize accuracy and actionability in recommendations  
- Flag unclear documentation and suggest alternative approaches  
- Delegate to subagents for retrieval of needed documentation to gain completeness for accuracy and better decision making  
- Be proactive and suggest options when applicable based on overall project goals, saving time money and context  
- Save usage and work detail during every session, create and update session file for each day  
- Save .md file for daily session activities by date in YYYYMMDD format, and place in github folder under systemgoat \- factory file by correct file tree for easy retrieval for other users

## Tasks

- Start of each day, open task list and analyze priorities and previous session summaries.   
- Use task list .md file from latest session   
- Update priorities as work is completed and needed based on strategic goals and current resource constraints  
- Ensure to analyze dependencies and notify if a task has dependencies that may delay project efficiently being completed  
- Generate OAuth codes and save them in folders for easy retraction later by other users  
- At each end of day, compact work for the day and summarize in one paragraph what was done and what is in-process.  Note any tools used and needed resources to complete ongoing tasks in future sessions  
- Note recommendations and problems during session for future analysis and improvement  
- Make suggestions based on new knowledge and always update task list before moving on to other task

# SUBAGENTS

# **CLAUDE CODE SUBAGENT GUIDE**

## **FILE ACCESS \- how agents access the files**

**Each agent does:**

1. Opens browser → pocketbase.systemgoat.com  
2. Logs in  
3. Clicks their collection (e.g., "agent\_1\_sales\_memory")  
4. Creates new record:  
   * Date: Today  
   * Topic: "Cold email results"  
   * Content: Paste their summary  
   * Tags: "leads, testing, roofing"  
5. Save  
6. Done \- visible to Manager Claude when it reads PocketBase

PocketBase Collections (Database Tables):

## 📁 agent\_1\_sales\_memory

├── Fields: date, topic, content, tags, status  
├── Example records:  
│   ├── "Market research Austin roofing \- Jan 28"  
│   ├── "Cold email subject line test results"  
│   ├── "10 objections logged \+ responses"  
│   └── "Lead data \- 45 prospects qualified"

## 📁 agent\_2\_infrastructure\_memory

├── Fields: date, topic, content, tags, status  
├── Example records:  
│   ├── "VPS monitoring setup \- Jan 28"  
│   ├── "Caddy config backup \- working version"  
│   ├── "Docker container status \+ alerts"  
│   └── "SSL certificate renewal schedule"

## 📁 agent\_3\_marketing\_memory

├── Fields: date, topic, content, tags, status  
├── Example records:  
│   ├── "Roofing LP version 1.2 \- copy"  
│   ├── "Google Ads campaign setup"  
│   ├── "A/B test results \- headline variations"  
│   └── "Email sequence \- open rate 12%"

## 📁 agent\_4\_operations\_memory

├── Fields: date, topic, content, tags, status  
├── Example records:  
│   ├── "Task board status \- Jan 28"  
│   ├── "Critical path analysis"  
│   ├── "Blocker alert: VPS disk 50%"  
│   └── "Decision log: AWS upgrade approved"

## 📁 Agent\_5\_shared\_memory

├── Fields: date, topic, content, tags, linked\_agents  
├── Example records:  
│   ├── "Customer avatar \- roofing contractors"  
│   ├── "Competitive analysis \- Thumbtack vs us"  
│   ├── "DECISION: Austin roofing focus \- why"  
│   └── "Business goals: $8K MRR in 26 days"

# PROJECT DETAIL

## LEAD GEN TASK SUMMARY

## **Focus on delegation over working in longer context windows.  /clear to start new focus where applicable**

### SCRAPING DATA

Using Apify, or other scraping tool, search, filter and retrieve relevant data for project scope and parameters.  Do not overlook details needed to ensure success in following steps. Think big picture.  Use the delegated agents where applicable and add to the team list as needed below based on project relevance. If team or individual subagents can be used in 2 or more instances, copy the details for efficient workflow and overall project success. If subagent is on a team of more than 4, do not share that subagent. Create a new one with similar abilities to ensure context is not lost.

### Lead Generation Focus \- 3 TEAMS (9 agents total) at revenue bottlenecks:

## **Team 1 (Acquisition):** Get 25-30 leads/week → pass to Team 2 \-**Team 2 (Qualification):** Filter 25-30 → 8-12 qualified → pass to Team 3  –**Team 3 (Conversion):** Turn 8-12 qualified → 3-5 discovery calls → pass to sales

## **Key advantage:** Each agent is hyper-focused. Qualification agent does scoring ONLY (transferable to other verticals). Content agent writes emails (transferable to commercial, multiple industries).

## **Your role:** Manage 3 reports/day (15 min), provide feedback, ensure quality gates pass.

