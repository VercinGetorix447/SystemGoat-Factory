#!/bin/bash
# Select a file first
FILE=$(ls *.md | fzf --header="Select Markdown file to move")
# Choose destination folder
DEST=$(find . -maxdepth 2 -type d | fzf --header="Select destination folder")
# Move and push to GitHub
mv "$FILE" "$DEST/" && git add . && git commit -m "Moved $FILE to $DEST" && git push origin main
