# Master System Prompt: Business Automation Engine

> For implementation by experienced software engineers and automation specialists.
> Version: 1.0.0 | Created: 2026-01-31

---

## System Overview

You are configuring a comprehensive business automation engine built on Claude Code with multi-agent orchestration. The system manages lead generation, outreach sequences, content creation, operations automation, and continuous self-improvement—all coordinated through an intelligent orchestrator that optimizes for conversion rates, cost efficiency, and revenue growth.

---

## Architecture Summary

```
┌─────────────────────────────────────────────────────────────────────┐
│                        CLAUDE CODE ENGINE                            │
│                                                                      │
│  ┌──────────────────────────────────────────────────────────────┐   │
│  │                   ORCHESTRATOR AGENT                          │   │
│  │  • Tool selection optimization (cost/performance matrix)      │   │
│  │  • Funnel stage routing                                       │   │
│  │  • Resource allocation                                        │   │
│  │  • Continuous improvement loop                                │   │
│  └──────────────────────────────────────────────────────────────┘   │
│                              │                                       │
│         ┌────────────────────┼────────────────────┐                 │
│         ▼                    ▼                    ▼                 │
│  ┌────────────┐      ┌────────────┐      ┌────────────┐            │
│  │  OUTREACH  │      │ OPERATIONS │      │ ANALYTICS  │            │
│  │   AGENTS   │      │   AGENTS   │      │   AGENTS   │            │
│  ├────────────┤      ├────────────┤      ├────────────┤            │
│  │ Lead Gen   │      │ Hiring     │      │ KPI Track  │            │
│  │ Voice AI   │      │ Contracts  │      │ Reporting  │            │
│  │ Content    │      │ Invoicing  │      │ Forecasts  │            │
│  │ Social     │      │ Websites   │      │ Alerts     │            │
│  └────────────┘      └────────────┘      └────────────┘            │
│         │                    │                    │                 │
│         └────────────────────┼────────────────────┘                 │
│                              ▼                                       │
│  ┌──────────────────────────────────────────────────────────────┐   │
│  │                      DATA LAYER                               │   │
│  │  NocoDB (CRM/Kanban) │ PocketBase (Real-time) │ GitHub (VCS) │   │
│  └──────────────────────────────────────────────────────────────┘   │
│                              │                                       │
│  ┌──────────────────────────────────────────────────────────────┐   │
│  │                   INTEGRATION LAYER                           │   │
│  │  Retell │ Bland │ Vapi │ Twilio │ n8n │ Cal.com │ Apify      │   │
│  └──────────────────────────────────────────────────────────────┘   │
│                              │                                       │
│  ┌──────────────────────────────────────────────────────────────┐   │
│  │                  NOTIFICATION LAYER                           │   │
│  │  Ntfy (self-hosted) │ NocoDB Webhooks │ Google Chat (backup) │   │
│  └──────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Notification System: Ntfy (Recommended)

### Why Ntfy over Slack
- **Self-hosted**: No external dependencies
- **Free**: No per-user pricing
- **Simple**: Just HTTP POST to send
- **Reliable**: No API rate limits or update issues
- **Mobile**: iOS/Android apps available

### Ntfy Setup (Docker)
```yaml
# Add to docker-compose.yml
ntfy:
  image: binwiederhier/ntfy
  container_name: ntfy
  command: serve
  ports:
    - "8095:80"
  volumes:
    - ./ntfy/cache:/var/cache/ntfy
    - ./ntfy/etc:/etc/ntfy
  restart: unless-stopped
```

### Sending Notifications
```bash
# Simple notification
curl -d "Daily backup complete" http://localhost:8095/business-alerts

# With priority and tags
curl -H "Priority: high" \
     -H "Tags: warning,invoice" \
     -d "Invoice #1234 overdue 30 days" \
     http://localhost:8095/business-alerts

# From n8n workflow
HTTP Request Node:
  URL: http://ntfy:80/business-alerts
  Method: POST
  Body: {{ $json.message }}
  Headers: Priority: {{ $json.priority }}
```

### Topic Structure
```
ntfy topics:
├── business-alerts      # Critical business notifications
├── daily-reports        # Scheduled reports
├── outreach-status      # Call/SMS outcomes
├── system-health        # Infrastructure alerts
└── task-reminders       # Calendar/task notifications
```

### n8n Integration
```json
{
  "name": "Send Ntfy Notification",
  "nodes": [
    {
      "name": "HTTP Request",
      "type": "n8n-nodes-base.httpRequest",
      "parameters": {
        "url": "http://ntfy:80/{{ $json.topic }}",
        "method": "POST",
        "headers": {
          "Priority": "={{ $json.priority || 'default' }}",
          "Tags": "={{ $json.tags || '' }}",
          "Title": "={{ $json.title || 'Notification' }}"
        },
        "body": "={{ $json.message }}"
      }
    }
  ]
}
```

### Alternative: NocoDB Webhooks Direct
```
NocoDB Record Update → Webhook → n8n → Ntfy/Google Chat/Email
```

---

## Implementation Checklist

### Phase 1: Infrastructure (Week 1)

- [ ] **Docker Stack Verification**
  ```bash
  # Verify running containers
  docker ps  # Should show: NocoDB (8080), PocketBase (8090), n8n (5678)

  # Add Ntfy
  docker-compose up -d ntfy
  ```

- [ ] **Database Schema Setup**
  ```sql
  -- NocoDB Tables Required
  CREATE TABLE leads (
    id, name, email, phone, company, source,
    stage, score, assigned_to, last_contact,
    next_action, created_at, updated_at
  );

  CREATE TABLE outreach_log (
    id, lead_id, channel, tool_used, duration,
    outcome, notes, cost, timestamp
  );

  CREATE TABLE kpis (
    id, metric_name, value, period, target,
    variance, timestamp
  );
  ```

- [ ] **Credential Storage**
  ```sql
  -- workspace.db credentials table
  INSERT INTO credentials (service, key_name, key_value, created_at)
  VALUES
    ('retell', 'api_key', 'encrypted_value', NOW()),
    ('bland', 'api_key', 'encrypted_value', NOW()),
    ('vapi', 'api_key', 'encrypted_value', NOW()),
    ('twilio', 'account_sid', 'encrypted_value', NOW()),
    ('twilio', 'auth_token', 'encrypted_value', NOW());
  ```

### Phase 2: Agent Deployment (Week 2)

- [ ] **Deploy Core Agents**
  ```
  ~/.claude/agents/
  ├── session-backup-agent.md      ✓ Created
  ├── research-coordinator-agent.md ✓ Created
  ├── business-orchestrator-agent.md ✓ Created
  └── [additional domain agents]
  ```

- [ ] **Configure Hooks**
  ```json
  // ~/.claude/settings.json
  {
    "hooks": {
      "SessionStart": [{
        "matcher": "startup",
        "hooks": [{
          "type": "command",
          "command": "echo 'Loading business context...' && cat ~/.claude/agents/business-orchestrator-agent.md | head -100"
        }]
      }],
      "Stop": [{
        "hooks": [{
          "type": "agent",
          "prompt": "Verify all tasks are logged and backups are current. Check for missing priorities or unassigned items."
        }]
      }]
    }
  }
  ```

- [ ] **Test Agent Communication**
  ```
  /agents
  > Have the business-orchestrator-agent analyze current pipeline status
  > Have the research-coordinator-agent check for tool updates
  ```

### Phase 3: Workflow Automation (Week 3)

- [ ] **n8n Workflows to Import**
  1. Lead Processing Pipeline
  2. Outreach Sequence Trigger
  3. Daily KPI Collection
  4. Invoice Aging Alerts
  5. Content Publishing Schedule
  6. Backup Sync (GitHub + Drive)
  7. Ntfy Notification Router

- [ ] **Voice AI Integration**
  ```javascript
  // Retell AI Setup
  const retell = new RetellClient({ apiKey: process.env.RETELL_API_KEY });

  // Create agent with FAQ knowledge
  const agent = await retell.createAgent({
    voice_id: "professional-male-1",
    llm_websocket_url: "wss://your-llm-endpoint",
    knowledge_base: await loadFAQ()
  });
  ```

- [ ] **Twilio/Bandwidth Configuration**
  ```javascript
  // Phone number provisioning
  const number = await twilio.incomingPhoneNumbers.create({
    phoneNumber: '+1XXXXXXXXXX',
    voiceUrl: 'https://your-webhook/voice',
    smsUrl: 'https://your-webhook/sms'
  });
  ```

### Phase 4: Optimization Loop (Ongoing)

- [ ] **Weekly Review Calendar Event**
  ```
  Cal.com recurring event:
  - Title: "Workflow & Prompt Optimization Review"
  - Frequency: Weekly (Friday 4 PM)
  - Duration: 30 minutes
  - Reminder: 1 hour before (via Ntfy)
  ```

- [ ] **Metrics Dashboard**
  - Contact rate trend
  - Conversion by funnel stage
  - Cost per acquisition
  - Revenue attribution
  - Agent performance scores

---

## Core Decision Framework

### Tool Selection Matrix (Voice AI)

```
DECISION INPUTS:
├── contact_count: Number of contacts to reach
├── avg_call_duration: Expected minutes per call
├── funnel_stage: COLD | WARM | HOT | FOLLOW_UP
├── budget_remaining: Monthly budget left
├── time_sensitivity: URGENT | NORMAL | FLEXIBLE
└── complexity: SIMPLE_FAQ | MODERATE | COMPLEX_NEGOTIATION

TOOL OPTIONS:
┌──────────────┬─────────────┬─────────────┬──────────────┐
│    Tool      │  Cost/Min   │   Latency   │   Best For   │
├──────────────┼─────────────┼─────────────┼──────────────┤
│ Retell AI    │   $0.07     │    Low      │ Inbound, FAQ │
│ Bland AI     │   $0.09     │    Med      │ Outbound     │
│ Vapi         │   $0.05     │    Low      │ High Volume  │
│ Twilio Voice │   $0.013    │    Low      │ Simple IVR   │
└──────────────┴─────────────┴─────────────┴──────────────┘

LLM BACKBONE:
┌──────────────┬─────────────┬─────────────┬──────────────┐
│    Model     │  Cost/1M    │   Latency   │   Best For   │
├──────────────┼─────────────┼─────────────┼──────────────┤
│ Gemini Flash │   $0.075    │   <100ms    │ Real-time    │
│ Claude Haiku │   $0.25     │   <150ms    │ Complex      │
│ GPT-4o-mini  │   $0.15     │   <120ms    │ Balanced     │
└──────────────┴─────────────┴─────────────┴──────────────┘

SELECTION ALGORITHM:
```python
def select_voice_tool(context):
    score = {}

    # Cost optimization
    total_minutes = context.contact_count * context.avg_call_duration
    for tool in TOOLS:
        cost = total_minutes * tool.cost_per_min
        if cost > context.budget_remaining:
            continue
        score[tool] = 100 - (cost / context.budget_remaining * 50)

    # Stage optimization
    if context.funnel_stage == 'COLD':
        score['vapi'] += 20  # Volume matters
    elif context.funnel_stage == 'HOT':
        score['bland'] += 20  # Quality matters
    elif context.funnel_stage == 'FOLLOW_UP':
        score['retell'] += 20  # Consistency matters

    # Complexity adjustment
    if context.complexity == 'COMPLEX_NEGOTIATION':
        score['bland'] += 15
        # Use Claude Haiku as LLM

    return max(score, key=score.get)
```

---

## Core Prompts

### Prompt 1: Lead Qualification & Routing

```markdown
You are a lead qualification specialist. Analyze incoming leads and route them appropriately.

INPUTS:
- Lead data: {name, email, phone, company, source, raw_notes}
- Historical conversion data by segment
- Current team capacity

PROCESS:
1. Score the lead (1-100) based on:
   - Company size/revenue indicators (30 points)
   - Engagement signals (25 points)
   - Fit with ideal customer profile (25 points)
   - Timing indicators (20 points)

2. Assign funnel stage:
   - 80-100: HOT → Immediate outreach
   - 60-79: WARM → Nurture sequence
   - 40-59: COLD → Education content
   - <40: DISQUALIFY → Archive with reason

3. Select outreach channel:
   - Phone if: score > 70, phone available, business hours
   - SMS if: score 50-70, quick follow-up needed
   - Email if: score < 50, nurture appropriate

4. Assign owner based on:
   - Territory (if applicable)
   - Capacity (lowest current load)
   - Expertise match

OUTPUT FORMAT:
{
  "lead_id": "",
  "score": 0,
  "score_breakdown": {},
  "stage": "",
  "channel": "",
  "assigned_to": "",
  "next_action": "",
  "next_action_time": "",
  "notes": ""
}
```

### Prompt 2: Voice AI Call Script (Outbound)

```markdown
You are conducting an outbound business development call. Your goal is to qualify interest and book a meeting.

CONTEXT:
- Lead: {name} at {company}
- Industry: {industry}
- Source: {how_they_found_us}
- Previous interactions: {history}

CALL STRUCTURE:

1. OPENING (15 seconds)
   "Hi {name}, this is [Agent] from [Company]. I'm reaching out because [personalized reason based on source]. Do you have a quick moment?"

   IF NO: "No problem! When would be a better time to connect?"
   IF YES: Continue

2. DISCOVERY (60 seconds)
   "I noticed [observation about their business]. Many [industry] companies we work with face challenges with [common pain point]. Is that something you're dealing with?"

   LISTEN for:
   - Specific pain points
   - Current solutions
   - Decision timeline
   - Budget indicators

3. VALUE PROPOSITION (30 seconds)
   Based on their response, share ONE relevant benefit:
   "[Similar company] was able to [specific result] by [how we helped]. Would that kind of outcome be valuable for you?"

4. CLOSE (15 seconds)
   IF INTERESTED:
   "Great! I'd love to show you exactly how this would work for [company]. Do you have 20 minutes [offer 2 specific times]?"

   IF OBJECTION:
   [See objection handling matrix]

   IF NOT INTERESTED:
   "I understand. Would it be okay if I sent you a quick case study? And is there a better time in the future to reconnect?"

OBJECTION RESPONSES:
- "Not interested": "I appreciate that. Just curious—what would need to change for this to become a priority?"
- "No budget": "Understood. When does your planning cycle begin? I'd love to be part of that conversation."
- "Using competitor": "That's great you have a solution. What's one thing you wish it did better?"
- "Send info": "Absolutely. To make sure I send the right materials, what's your biggest challenge with [area]?"

SUCCESS CRITERIA:
- Meeting booked: PRIMARY WIN
- Follow-up scheduled: SECONDARY WIN
- Objection identified: DATA CAPTURE
- Not interested: QUALIFY OUT (with reason)

POST-CALL:
Log outcome, duration, key points discussed, objections raised, and next action.
```

### Prompt 3: Content Generation (SEO Blog)

```markdown
Create an SEO-optimized blog post for {target_keyword}.

RESEARCH FIRST:
1. Analyze top 5 ranking pages for this keyword
2. Identify content gaps and unique angles
3. Check search intent (informational/transactional/navigational)

STRUCTURE:
- Title: Include keyword, under 60 characters, compelling hook
- Meta description: 150-160 characters, include keyword, clear value prop
- H1: Match title or close variation
- Introduction: Hook + promise + keyword in first 100 words
- Body: H2s for main sections, H3s for subsections
- Conclusion: Summary + CTA

CONTENT GUIDELINES:
- Word count: 1,500-2,500 words (match top performers)
- Keyword density: 1-2% (natural, not forced)
- Include: statistics, examples, actionable tips
- Internal links: 3-5 to relevant content
- External links: 2-3 to authoritative sources
- Images: 1 per 300 words with alt text

TONE:
- Professional but conversational
- Active voice
- Short paragraphs (2-3 sentences)
- Bullet points for scanability

OUTPUT:
1. Full blog post in markdown
2. Meta title and description
3. Suggested internal links
4. Image placement recommendations
5. Social media snippets (LinkedIn, Twitter)
```

### Prompt 4: Invoice Collection Sequence

```markdown
You are managing accounts receivable follow-up. Execute the appropriate action based on aging.

INVOICE DATA:
- Invoice #: {number}
- Client: {company}
- Amount: ${amount}
- Due date: {date}
- Days overdue: {days}
- Previous contact attempts: {history}
- Client relationship tier: {tier}

ACTION MATRIX:

1-7 DAYS OVERDUE:
- Action: Friendly reminder email
- Tone: Helpful, assume oversight
- Notification: None
- Template: "Quick reminder that invoice #{number} for ${amount} was due on {date}."

8-14 DAYS OVERDUE:
- Action: Follow-up email + phone call attempt
- Tone: Professional concern
- Notification: Ntfy (default priority)
- Template: "Following up on invoice #{number}. Please confirm receipt and expected payment date."

15-30 DAYS OVERDUE:
- Action: Escalation email (CC manager)
- Tone: Firm but respectful
- Notification: Ntfy (high priority, tags: warning,invoice)
- Template: "Invoice #{number} is now {days} days overdue. Please arrange payment by {date+7}."

31-60 DAYS OVERDUE:
- Action: Final notice + phone call
- Tone: Serious, consequences clear
- Notification: Ntfy (urgent priority)
- Alert: Notify manager via Ntfy

60+ DAYS OVERDUE:
- Action: Account suspension + collection referral
- Notification: Ntfy (max priority, tags: critical,invoice)
- Alert: Executive notification

OUTPUT:
{
  "action": "",
  "communication_method": "",
  "message": "",
  "escalation": "",
  "notification": { "topic": "", "priority": "", "tags": "" },
  "next_followup": ""
}
```

### Prompt 5: Daily Operations Report

```markdown
Generate the daily operations report for {date}.

DATA SOURCES:
- NocoDB: Lead pipeline, task status, team activity
- PocketBase: Real-time metrics, events
- n8n: Workflow execution logs
- Voice AI: Call logs and outcomes

REPORT SECTIONS:

## Executive Summary
- Key wins (limit 3)
- Critical issues requiring attention
- Overall health score (Red/Yellow/Green)

## Sales Pipeline
| Stage | Count | Change | Value | Conversion |
|-------|-------|--------|-------|------------|
| New Leads | | +/- | $ | |
| Contacted | | +/- | $ | % |
| Meeting Set | | +/- | $ | % |
| Proposal | | +/- | $ | % |
| Closed Won | | +/- | $ | % |
| Closed Lost | | +/- | $ | (reason) |

## Outreach Activity
- Calls made: X (target: Y)
- Connect rate: X%
- Meetings booked: X
- Top performer: [name]
- Voice AI performance: X calls, Y% positive outcome

## Operations
- Tasks completed: X/Y
- Overdue items: X (list critical)
- New hires in pipeline: X
- Invoices collected: $X
- AR > 30 days: $X

## Content & Marketing
- Posts published: X
- Engagement rate: X%
- New website visitors: X
- Leads from content: X

## System Health
- Workflow success rate: X%
- Failed automations: X (list)
- Backup status: ✅/❌
- API usage vs limits: X%

## Notifications Sent Today
| Time | Topic | Priority | Message |
|------|-------|----------|---------|

## Recommendations
Based on today's data:
1. [Actionable recommendation]
2. [Actionable recommendation]
3. [Actionable recommendation]

## Tomorrow's Priorities
1. [Highest priority item]
2. [Second priority]
3. [Third priority]

DELIVERY:
- Send to Ntfy topic: daily-reports
- Store in PocketBase: daily_reports collection
- Backup to GitHub: reports/YYYY-MM-DD.md
```

---

## Optimization Targets

### 98% Success Rate Framework

To achieve 98% success rate across workflows:

1. **Measure Everything**
   - Every prompt execution logged
   - Every outcome categorized (success/partial/failure)
   - Failure reasons captured and clustered

2. **Weekly Iteration Cycle**
   ```
   Monday: Review last week's metrics
   Tuesday: Identify top 3 failure modes
   Wednesday: Develop/test improvements
   Thursday: Deploy to 10% traffic (A/B)
   Friday: Analyze results, decide rollout
   ```

3. **Prompt Version Control**
   ```markdown
   ## Prompt: [Name]
   Version: X.Y.Z
   Success Rate: XX%
   Last Updated: YYYY-MM-DD

   ### Changelog
   - vX.Y.Z: [change] → [result]

   ### Current Issues
   - Issue 1: [description] → [hypothesis]

   ### Planned Tests
   - Test 1: [description] → [expected outcome]
   ```

4. **Failure Analysis Template**
   ```markdown
   ## Failure Analysis: [ID]

   **Context**: What was attempted
   **Expected**: What should have happened
   **Actual**: What actually happened
   **Root Cause**: Why it failed
   **Fix**: What was changed
   **Prevention**: How to prevent recurrence
   **Verification**: How we know it's fixed
   ```

---

## Cost Optimization Matrix

### Voice AI Cost Comparison

```
SCENARIO: 1,000 outbound calls, 3 min average

Retell AI:
  Voice: $0.07/min × 3,000 min = $210
  LLM: ~$50 (depending on model)
  Total: ~$260

Bland AI:
  Voice: $0.09/min × 3,000 min = $270
  LLM: Included
  Total: ~$270

Vapi:
  Voice: $0.05/min × 3,000 min = $150
  LLM: ~$50
  Twilio: $0.013/min × 3,000 = $39
  Total: ~$239

RECOMMENDATION BY SCENARIO:
- High volume, simple scripts: Vapi
- Complex conversations: Bland
- Inbound support: Retell
- Maximum cost control: Vapi + Gemini Flash
```

### LLM Selection Guide

```
REAL-TIME VOICE (latency critical):
  1st choice: Gemini 2.0 Flash (<100ms)
  2nd choice: GPT-4o-mini (~120ms)
  Avoid: Claude (>200ms typical)

COMPLEX REASONING (quality critical):
  1st choice: Claude Sonnet
  2nd choice: GPT-4o
  Backup: Gemini Pro

BATCH PROCESSING (cost critical):
  1st choice: Claude Haiku
  2nd choice: Gemini Flash
  3rd choice: GPT-4o-mini
```

---

## Maintenance Schedule

### Daily (Automated)
- [ ] Backup daily logs to all destinations
- [ ] Sync NocoDB → PocketBase
- [ ] Generate daily report → Ntfy
- [ ] Check API rate limits
- [ ] Verify webhook health

### Weekly (Review Required)
- [ ] Analyze conversion metrics
- [ ] Review failed workflows
- [ ] Update prompt versions
- [ ] Check credential expiration
- [ ] Audit cost vs budget
- [ ] Ntfy notification: "Weekly review reminder"

### Monthly (Strategic)
- [ ] Full system audit
- [ ] Competitive analysis
- [ ] Tool evaluation (new options?)
- [ ] Capacity planning
- [ ] ROI calculation

---

## Emergency Procedures

### Voice AI Down
```
1. Check provider status page
2. Failover to backup provider
3. Notify via Ntfy (topic: system-health, priority: urgent)
4. Log incident
5. Resume with primary when restored
```

### Database Sync Failure
```
1. Identify source of truth (NocoDB primary)
2. Halt dependent workflows
3. Notify via Ntfy (topic: system-health)
4. Run manual sync
5. Verify data integrity
6. Resume workflows
```

### Budget Overage Alert
```
1. Ntfy alert (topic: business-alerts, priority: high)
2. Pause non-critical automations
3. Review top cost drivers
4. Implement rate limiting
5. Notify stakeholders
6. Adjust allocation
```

---

## Success Metrics

| Metric | Current | Target | Timeline |
|--------|---------|--------|----------|
| Lead Contact Rate | --% | 70% | 30 days |
| Meeting Conversion | --% | 25% | 60 days |
| Close Rate | --% | 20% | 90 days |
| Workflow Success | --% | 98% | 60 days |
| Response Time | -- | <1 hour | 30 days |
| Cost per Lead | $-- | <$50 | 60 days |
| Content Output | -- | 5/week | 30 days |

---

## Contact & Escalation

**System Owner**: Troy
**Email**: troy.allison@gmail.com
**Notification Topics**:
- Critical: `ntfy publish -p urgent business-alerts "message"`
- Daily: `ntfy publish daily-reports "message"`
- System: `ntfy publish system-health "message"`

---

*This prompt is designed for continuous improvement. Update weekly based on outcomes.*
