# Prompt Template

> Quick-save format for prompts, workflows, and automation sequences.
> Copy this template, fill in sections, save as `prompts/YYYY-MM-DD-{name}.md`

---

## Metadata

| Field | Value |
|-------|-------|
| **ID** | `prompt-{YYYYMMDD}-{001}` |
| **Name** | |
| **Category** | `outreach` / `automation` / `data` / `integration` / `calendar` / `other` |
| **Version** | `1.0.0` |
| **Created** | `YYYY-MM-DD` |
| **Last Updated** | `YYYY-MM-DD` |
| **Author** | Troy / Claude |
| **Status** | `draft` / `testing` / `active` / `archived` |
| **Success Rate** | `---%` (target: 98%) |

---

## Purpose

**Goal**: (One sentence - what does this prompt/workflow achieve?)

**Use Case**:
- [ ] Customer Finding
- [ ] Outreach (Call/Text)
- [ ] Data Scraping
- [ ] CRM Update
- [ ] Calendar/Scheduling
- [ ] Reporting
- [ ] Other: ___________

**Integrations**:
- [ ] Retell AI
- [ ] Bland AI
- [ ] Vapi
- [ ] Twilio
- [ ] NocoDB
- [ ] PocketBase
- [ ] Supabase
- [ ] GitHub
- [ ] n8n
- [ ] Cal.com
- [ ] Apify
- [ ] Other: ___________

---

## Trigger

**Type**: `manual` / `scheduled` / `webhook` / `event-based`

**Schedule** (if applicable):
- Frequency: `hourly` / `daily` / `weekly` / `monthly`
- Time:
- Timezone: PST

**Event Trigger** (if applicable):
- Source:
- Condition:

---

## The Prompt

```
[PASTE YOUR PROMPT HERE]

Context:
-

Instructions:
1.
2.
3.

Expected Output:
-

Constraints:
-
```

---

## Workflow Steps

```mermaid
graph TD
    A[Trigger] --> B[Step 1]
    B --> C[Step 2]
    C --> D[Output]
```

| Step | Action | Tool/Service | Input | Output |
|------|--------|--------------|-------|--------|
| 1 | | | | |
| 2 | | | | |
| 3 | | | | |

---

## Data Schema

**Input Fields**:
```json
{
  "field_name": "type | description"
}
```

**Output Fields**:
```json
{
  "field_name": "type | description"
}
```

---

## Success Metrics

| Metric | Target | Current | Last Measured |
|--------|--------|---------|---------------|
| Success Rate | 98% | --% | YYYY-MM-DD |
| Response Time | | | |
| Conversion Rate | | | |
| Error Rate | <2% | --% | |

---

## Iteration Log

| Version | Date | Changes | Result | Notes |
|---------|------|---------|--------|-------|
| 1.0.0 | YYYY-MM-DD | Initial version | | |
| | | | | |

---

## Best Practices Applied

- [ ] Clear, specific instructions
- [ ] Defined success criteria
- [ ] Error handling included
- [ ] Fallback logic defined
- [ ] Rate limits respected
- [ ] Data validation in place
- [ ] Logging enabled
- [ ] Rollback plan exists

---

## Review Schedule

**Weekly Review**: Every [DAY] at [TIME]
- [ ] Check success metrics
- [ ] Review error logs
- [ ] Update prompt based on outcomes
- [ ] Document improvements

---

## Related Prompts/Workflows

- Link to related prompt 1
- Link to related prompt 2

---

## Notes

```
Additional context, lessons learned, or future improvements:

```
